# DevisPro — MVP de départ

## Important
Ce projet est un prototype de démarrage, pas un service prêt à vendre. Il n'a pas été compilé ni testé dans cet environnement. Certaines fonctions restent à compléter : liste/édition des devis et clients, profil entreprise, numérotation robuste, limites d'abonnement, Stripe et conformité des documents. Vérifier les règles françaises applicables avant utilisation professionnelle.

## Configuration
1. Créer un projet Supabase.
2. Dans SQL Editor, exécuter `supabase/schema.sql`.
3. Copier `.env.example` vers `.env.local`.
4. Renseigner `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY` avec la Project URL et la Publishable key (jamais une clé secret/service_role).
5. Installer Node.js puis lancer `npm install` et `npm run dev`.

## Publication
Le déploiement sur Vercel nécessite de connecter le dépôt Git et d'ajouter les deux variables d'environnement. Vérifier les conditions d'âge des services et demander l'aide d'un parent/responsable légal pour toute création de compte ou activité commerciale nécessitant un adulte.

## Tarifs
Les tarifs Free / Pro / Business ne sont que des idées d'offre dans ce prototype. Aucun paiement Stripe n'est activé.
